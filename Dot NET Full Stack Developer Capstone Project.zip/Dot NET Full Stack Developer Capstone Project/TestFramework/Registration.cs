﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace TestFramework
{
    class Registration
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }

    }
}
