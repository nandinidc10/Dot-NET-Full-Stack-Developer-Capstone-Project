﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ehealthcare.Entities.Dto
{
    public class LoginDto
    {
        public string Email { get; set; }

        public string Password { get; set; }

        public string Type { get; set; }
    }
}
